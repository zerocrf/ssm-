package in.bushansirgur.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import in.bushansirgur.dao.QueriesMapper;
import in.bushansirgur.entity.Queries;


@Controller @RequestMapping("/queries")
public class QueriesController {

	@Autowired
	QueriesMapper queriesMapper;
	
	private static final String QUERIES = "Queries";
	private static final String QUERIESLIST = "ListQueries";
	
	@RequestMapping("/listOfQueries")
	public String showListOfQueries(Model model){
		model.addAttribute("queriesList", queriesMapper.getAllQueries());
		return QUERIESLIST;
	}
	
	@RequestMapping("/showFormForAdd")
	public String addQueries(Model model){
		model.addAttribute("queries", new Queries());
		return QUERIES;
	}
	
	@RequestMapping("/saveProcess")
	public String saveQueries(@ModelAttribute("queries") Queries queries){
		if(queries.getId() == null){
			queriesMapper.saveQueries(queries);
		}else{
			queriesMapper.saveQueries(queries);
		}
		
		return "redirect:/queries/listOfQueries";
	}
	
	@RequestMapping("/displayUpdateForm")
	public String showUpdateQueriesForm(@RequestParam("queriesId") int queriesId, Model model){
		model.addAttribute("queries", queriesMapper.findQueriesById(queriesId));
		return QUERIES;
	}
	
	@RequestMapping("/displayDeleteForm")
	public String deleteQueries(@RequestParam("queriesId") int queriesId){
		queriesMapper.deleteQueries(queriesId);
		return "redirect:/queries/listOfQueries";
	}
}
