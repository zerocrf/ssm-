package in.bushansirgur.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import in.bushansirgur.dao.SubaccountMapper;
import in.bushansirgur.entity.Subaccount;


@Controller @RequestMapping("/subaccount")
public class SubaccountController {

	@Autowired
	SubaccountMapper subaccountMapper;
	
	private static final String SUBACCOUNT = "Subaccount";
	private static final String SUBACCOUNTLIST = "ListSubaccounts";
	
	@RequestMapping("/listOfSubaccount")
	public String showListOfSubaccounts(Model model){
		model.addAttribute("subaccountList", subaccountMapper.getAllSubaccounts());
		return SUBACCOUNTLIST;
	}
	
	@RequestMapping("/showFormForAdd")
	public String addSubaccount(Model model){
		model.addAttribute("subaccount", new Subaccount());
		return SUBACCOUNT;
	}
	
	@RequestMapping("/saveProcess")
	public String saveSubaccount(@ModelAttribute("subaccount") Subaccount subaccount){
		if(subaccount.getId() == null){
			subaccountMapper.saveSubaccount(subaccount);
		}else{
			subaccountMapper.updateSubaccount(subaccount);
		}
		
		return "redirect:/subaccount/listOfSubaccount";
	}
	
	@RequestMapping("/displayUpdateForm")
	public String showUpdateSubaccountForm(@RequestParam("subaccountId") int subaccountId, Model model){
		model.addAttribute("subaccount", subaccountMapper.findSubaccountById(subaccountId));
		return SUBACCOUNT;
	}
	
	@RequestMapping("/displayDeleteForm")
	public String deleteSubaccount(@RequestParam("subaccountId") int subaccountId){
		subaccountMapper.deleteSubaccount(subaccountId);
		return "redirect:/subaccount/listOfSubaccount";
	}
}
