package in.bushansirgur.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import in.bushansirgur.dao.VarietiesMapper;
import in.bushansirgur.entity.Varieties;


@Controller @RequestMapping("/varieties")
public class VarietiesController {

	@Autowired
	VarietiesMapper varietiesMapper;
	
	private static final String VARIETIES = "Varieties";
	private static final String VARIETIESLIST = "ListVarieties";
	
	@RequestMapping("/listOfVarieties")
	public String showListOfVarieties(Model model){
		model.addAttribute("varietiesList", varietiesMapper.getAllVarieties());
		return VARIETIESLIST;
	}
	
	@RequestMapping("/showFormForAdd")
	public String addVarieties(Model model){
		model.addAttribute("varieties", new Varieties());
		return VARIETIES;
	}
	
	@RequestMapping("/saveProcess")
	public String saveVarieties(@ModelAttribute("varieties") Varieties varieties){
		if(varieties.getId() == null){
			varietiesMapper.saveVarieties(varieties);
		}else{
			varietiesMapper.updateVarieties(varieties);
		}
		
		return "redirect:/varieties/listOfVarieties";
	}
	
	@RequestMapping("/displayUpdateForm")
	public String showUpdateVarietiesForm(@RequestParam("varietiesId") int varietiesId, Model model){
		model.addAttribute("varieties", varietiesMapper.findVarietiesById(varietiesId));
		return VARIETIES;
	}
	
	@RequestMapping("/displayDeleteForm")
	public String deleteVarieties(@RequestParam("varietiesId") int varietiesId){
		varietiesMapper.deleteVarieties(varietiesId);
		return "redirect:/varieties/listOfVarieties";
	}
}
