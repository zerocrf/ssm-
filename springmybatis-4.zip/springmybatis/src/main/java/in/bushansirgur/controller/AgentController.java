package in.bushansirgur.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import in.bushansirgur.dao.AgentMapper;
import in.bushansirgur.entity.Agent;


@Controller @RequestMapping("/agent")
public class AgentController {

	@Autowired
	AgentMapper agentMapper;
	
	private static final String AGENT = "Agent";
	private static final String AGENTLIST = "ListAgents";
	
	@RequestMapping("/listOfAgent")
	public String showListOfAgents(Model model){
		model.addAttribute("agentList", agentMapper.getAllAgents());
		return AGENTLIST;
	}
	
	@RequestMapping("/showFormForAdd")
	public String addAgent(Model model){
		model.addAttribute("agent", new Agent());
		return AGENT;
	}
	
	@RequestMapping("/saveProcess")
	public String saveAgent(@ModelAttribute("agent") Agent agent){
		if(agent.getId() == null){
			agentMapper.saveAgent(agent);
		}else{
			agentMapper.updateAgent(agent);
		}
		
		return "redirect:/agent/listOfAgent";
	}
	
	@RequestMapping("/displayUpdateForm")
	public String showUpdateAagentForm(@RequestParam("agentId") int agentId, Model model){
		model.addAttribute("agent", agentMapper.findAgentById(agentId));
		return AGENT;
	}
	
	@RequestMapping("/displayDeleteForm")
	public String deleteAgent(@RequestParam("agentId") int agentId){
		agentMapper.deleteAgent(agentId);
		return "redirect:/agent/listOfAgent";
	}
}
