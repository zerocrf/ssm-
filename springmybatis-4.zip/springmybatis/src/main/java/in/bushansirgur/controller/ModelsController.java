package in.bushansirgur.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import in.bushansirgur.dao.ModelsMapper;
import in.bushansirgur.entity.Models;


@Controller @RequestMapping("/models")
public class ModelsController {

	@Autowired
	ModelsMapper modelsMapper;
	
	private static final String MODELS = "Models";
	private static final String MODELSLIST = "ListModels";
	
	@RequestMapping("/listOfModels")
	public String showListOfModels(Model model){
		model.addAttribute("modelsList", modelsMapper.getAllModels());
		return MODELSLIST;
	}
	
	@RequestMapping("/showFormForAdd")
	public String addModels(Model model){
		model.addAttribute("models", new Models());
		return MODELS;
	}
	
	@RequestMapping("/saveProcess")
	public String saveModels(@ModelAttribute("models") Models models){
		if(models.getId() == null){
			modelsMapper.saveModels(models);
		}else{
			modelsMapper.updateModels(models);
		}
		
		return "redirect:/models/listOfModels";
	}
	
	@RequestMapping("/displayUpdateForm")
	public String showUpdateModelsForm(@RequestParam("modelsId") int modelsId, Model model){
		model.addAttribute("models", modelsMapper.findModelsById(modelsId));
		return MODELS;
	}
	
	@RequestMapping("/displayDeleteForm")
	public String deleteModels(@RequestParam("modelsId") int modelsId){
		modelsMapper.deleteModels(modelsId);
		return "redirect:/models/listOfModels";
	}
}
