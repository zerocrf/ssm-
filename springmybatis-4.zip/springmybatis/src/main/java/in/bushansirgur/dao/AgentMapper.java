package in.bushansirgur.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import in.bushansirgur.entity.Agent;
import in.bushansirgur.util.MyBatisUtil;


@Repository
public class AgentMapper {
	
	public void saveAgent(Agent agent){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		session.insert("insertAgent", agent);
		session.commit();
		session.close();
	}
	
	public void updateAgent(Agent agent){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		session.update("updateAgent", agent);
		session.commit();
		session.close();
	}
	
	public void deleteAgent(int agentId){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		session.delete("deleteAgent", agentId);
		session.commit();
		session.close();
	}
	
	public List<Agent> getAllAgents(){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		@SuppressWarnings("unchecked")
		List<Agent> agentList = session.selectList("getAllAgents");
		session.commit();
		session.close();
		return agentList;
	}
	
	public Agent findAgentById(int agentId){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		Agent agent = (Agent) session.selectOne("findAgentById", agentId);
		session.commit();
		session.close();
		return agent;
	}
}
