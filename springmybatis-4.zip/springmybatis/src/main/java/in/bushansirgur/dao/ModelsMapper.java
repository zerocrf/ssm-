package in.bushansirgur.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import in.bushansirgur.entity.Models;
import in.bushansirgur.util.MyBatisUtil;


@Repository
public class ModelsMapper {
	
	public void saveModels(Models models){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		session.insert("insertModels", models);
		session.commit();
		session.close();
	}
	
	public void updateModels(Models models){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		session.update("updateModels", models);
		session.commit();
		session.close();
	}
	
	public void deleteModels(int modelsId){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		session.delete("deleteModels", modelsId);
		session.commit();
		session.close();
	}
	
	public List<Models> getAllModels(){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		@SuppressWarnings("unchecked")
		List<Models> modelsList = session.selectList("getAllModels");
		session.commit();
		session.close();
		return modelsList;
	}
	
	public Models findModelsById(int modelsId){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		Models models = (Models) session.selectOne("findModelsById", modelsId);
		session.commit();
		session.close();
		return models;
	}
}
