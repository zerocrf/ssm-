package in.bushansirgur.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import in.bushansirgur.entity.Queries;
import in.bushansirgur.util.MyBatisUtil;


@Repository
public class QueriesMapper {
	
	public void saveQueries(Queries queries){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		session.insert("insertQueries", queries);
		session.commit();
		session.close();
	}
	
	public void updateQueries(Queries queries){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		session.update("updateQueries", queries);
		session.commit();
		session.close();
	}
	
	public void deleteQueries(int queriesId){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		session.delete("deleteQueries", queriesId);
		session.commit();
		session.close();
	}
	
	public List<Queries> getAllQueries(){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		@SuppressWarnings("unchecked")
		List<Queries> queriesList = session.selectList("getAllQueries");
		session.commit();
		session.close();
		return queriesList;
	}
	
	public Queries findQueriesById(int queriesId){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		Queries queries = (Queries) session.selectOne("findQueriesById", queriesId);
		session.commit();
		session.close();
		return queries;
	}
}
