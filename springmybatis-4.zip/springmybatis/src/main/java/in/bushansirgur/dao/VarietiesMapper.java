package in.bushansirgur.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import in.bushansirgur.entity.Varieties;
import in.bushansirgur.util.MyBatisUtil;


@Repository
public class VarietiesMapper {
	
	public void saveVarieties(Varieties varieties){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		session.insert("insertVarieties", varieties);
		session.commit();
		session.close();
	}
	
	public void updateVarieties(Varieties varieties){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		session.update("updateVarieties", varieties);
		session.commit();
		session.close();
	}
	
	public void deleteVarieties(int varietiesId){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		session.delete("deleteVarieties", varietiesId);
		session.commit();
		session.close();
	}
	
	public List<Varieties> getAllVarieties(){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		@SuppressWarnings("unchecked")
		List<Varieties> varietiesList = session.selectList("getAllVarieties");
		session.commit();
		session.close();
		return varietiesList;
	}
	
	public Varieties findVarietiesById(int varietiesId){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		Varieties varieties = (Varieties) session.selectOne("findVarietiesById", varietiesId);
		session.commit();
		session.close();
		return varieties;
	}
}
