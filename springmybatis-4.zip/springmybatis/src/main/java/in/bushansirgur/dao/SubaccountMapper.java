package in.bushansirgur.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import in.bushansirgur.entity.Subaccount;
import in.bushansirgur.util.MyBatisUtil;


@Repository
public class SubaccountMapper {
	
	public void saveSubaccount(Subaccount subaccount){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		session.insert("insertSubaccount", subaccount);
		session.commit();
		session.close();
	}
	
	public void updateSubaccount(Subaccount subaccount){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		session.update("updateSubaccount", subaccount);
		session.commit();
		session.close();
	}
	
	public void deleteSubaccount(int SubaccountId){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		session.delete("deleteSubaccount", SubaccountId);
		session.commit();
		session.close();
	}
	
	public List<Subaccount> getAllSubaccounts(){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		@SuppressWarnings("unchecked")
		List<Subaccount> subaccountList = session.selectList("getAllSubaccounts");
		session.commit();
		session.close();
		return subaccountList;
	}
	
	public Subaccount findSubaccountById(int subaccountId){
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		Subaccount subaccount = (Subaccount) session.selectOne("findSubaccountById", subaccountId);
		session.commit();
		session.close();
		return subaccount;
	}
}
