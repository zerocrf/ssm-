package in.bushansirgur.entity;

public class Agent {
	
	private Integer id;
	private double fee;
	private double rebate_rate;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public double getFee() {
		return fee;
	}
	public void setFee(double fee) {
		this.fee = fee;
	}
	public double getRebate_rate() {
		return rebate_rate;
	}
	public void setRebate_rate(double rebate_rate) {
		this.rebate_rate = rebate_rate;
	}
}
