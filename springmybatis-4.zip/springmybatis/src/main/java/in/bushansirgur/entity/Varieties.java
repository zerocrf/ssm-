package in.bushansirgur.entity;

public class Varieties {
	
	private Integer id;
	private String opentime;
	private String main_contract;
	private String contents;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getOpentime() {
		return opentime;
	}
	public void setOpentime(String opentime) {
		this.opentime = opentime;
	}
	public String getMain_contract() {
		return main_contract;
	}
	public void setMain_contract(String main_contract) {
		this.main_contract = main_contract;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
}
