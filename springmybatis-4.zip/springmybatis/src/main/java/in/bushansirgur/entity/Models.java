package in.bushansirgur.entity;

public class Models {
	
	private Integer id;
	private double margin;
	private double agent_expense;
	private double subaccount_expense;
	private double trans_rate;
	private double rebate_rate;
	private String risk_control;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public double getagent_expense() {
		return agent_expense;
	}
	public void setagent_expense(double agent_expense) {
		this.agent_expense = agent_expense;
	}
	public double getMargin() {
		return margin;
	}
	public void setMargin(double margin) {
		this.margin = margin;
	}
	public double getTrans_rate() {
		return trans_rate;
	}
	public void setTrans_rate(double trans_rate) {
		this.trans_rate = trans_rate;
	}
	public double getSubaccount_expense() {
		return subaccount_expense;
	}
	public void setSubaccount_expense(double subaccount_expense) {
		this.subaccount_expense = subaccount_expense;
	}
	public double getRebate_rate() {
		return rebate_rate;
	}
	public void setRebate_rate(double rebate_rate) {
		this.rebate_rate = rebate_rate;
	}
	public String getRisk_control() {
		return risk_control;
	}
	public void setRisk_control(String risk_control) {
		this.risk_control = risk_control;
	}
}
