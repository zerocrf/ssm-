package in.bushansirgur.entity;

public class Subaccount {
	
	private Integer id;
	private double fee;
	private double margin;
	private double trans_rate;
	private String risk_control;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public double getFee() {
		return fee;
	}
	public void setFee(double fee) {
		this.fee = fee;
	}
	public double getMargin() {
		return margin;
	}
	public void setMargin(double margin) {
		this.margin = margin;
	}
	public double getTrans_rate() {
		return trans_rate;
	}
	public void setTrans_rate(double trans_rate) {
		this.trans_rate = trans_rate;
	}
	public String getRisk_control() {
		return risk_control;
	}
	public void setRisk_control(String risk_control) {
		this.risk_control = risk_control;
	}
}
