/*
SQLyog Community v12.15 (64 bit)
MySQL - 10.4.11-MariaDB : Database - customer_mgnt_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`customer_mgnt_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `customer_mgnt_db`;

/*Table structure for table `agents` */

DROP TABLE IF EXISTS `agents`;

CREATE TABLE `agents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fee` double DEFAULT NULL,
  `rebate_rate` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

/*Data for the table `agents` */

insert  into `agents`(`id`,`fee`,`rebate_rate`) values 
(2,3434,55);

/*Table structure for table `mainaccounts` */

DROP TABLE IF EXISTS `mainaccounts`;

CREATE TABLE `mainaccounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `hobbies` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

/*Data for the table `mainaccounts` */

insert  into `mainaccounts`(`id`,`fullname`,`email`,`gender`,`hobbies`,`country`,`address`) values 
(1,'dddddddfg','sf@dsf.com','Male','Browsing,Running','Sri Lanka','adfasdf');

/*Table structure for table `models` */

DROP TABLE IF EXISTS `models`;

CREATE TABLE `models` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `margin` double DEFAULT NULL,
  `agent_expense` double DEFAULT NULL,
  `subaccount_expense` double DEFAULT NULL,
  `trans_rate` double DEFAULT NULL,
  `rebate_rate` double DEFAULT NULL,
  `risk_control` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `models` */

/*Table structure for table `queries` */

DROP TABLE IF EXISTS `queries`;

CREATE TABLE `queries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deposit` double DEFAULT NULL,
  `withdrawal` double DEFAULT NULL,
  `commission` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `queries` */

/*Table structure for table `subaccounts` */

DROP TABLE IF EXISTS `subaccounts`;

CREATE TABLE `subaccounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fee` double DEFAULT NULL,
  `margin` double DEFAULT NULL,
  `trans_rate` double DEFAULT NULL,
  `risk_control` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

/*Data for the table `subaccounts` */

insert  into `subaccounts`(`id`,`fee`,`margin`,`trans_rate`,`risk_control`) values 
(2,6,87,67,'gjkgjkj'),
(4,0,0,78,'gjkgjhk');

/*Table structure for table `varieties` */

DROP TABLE IF EXISTS `varieties`;

CREATE TABLE `varieties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `opentime` datetime DEFAULT NULL,
  `main_contract` varchar(255) DEFAULT NULL,
  `contents` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `varieties` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
